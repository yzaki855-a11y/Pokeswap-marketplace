
# PokéSwap – MVP

A minimal Next.js + Tailwind + Prisma (SQLite) scaffold for a global Pokémon TCG marketplace with listings, offers, fee logic, and room for escrow/shipping integrations.

## Defaults you asked me to pick
- **Fees**: 8.5% marketplace + payment processor fees.
- **Launch countries**: USA, EU/EEA, UK, UAE, Japan.
- **Authenticity routing**: Phase 2 (optional send-to-grading before delivery).

## Quick start
```bash
pnpm i # or npm/yarn
cp .env.example .env
pnpm dlx prisma db push
pnpm dev
```
Open http://localhost:3000

## API
- `GET /api/listings` – list active listings
- `POST /api/listings` – create listing (JSON body per schema)
- `POST /api/offers` – create offer

> Prices are stored in **minor units** (e.g., cents).

## Data model
See `prisma/schema.prisma` (Users, Listings, Offers, Orders).

## Next steps
- Add Auth (Clerk/Auth.js magic links) + KYC (Onfido/Sumsub).
- Add Stripe Connect (destination charges + manual transfer) to hold escrow.
- Add Shippo/EasyPost for labels + tracking.
- Add disputes & release conditions (scan-delivered or buyer confirmation).
- Swap SQLite for Postgres in production, run on Vercel + Neon/Supabase.
