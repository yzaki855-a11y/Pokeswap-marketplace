
export const SUPPORTED_CURRENCIES = ['USD','EUR','AED','GBP','JPY'] as const;
export type Currency = typeof SUPPORTED_CURRENCIES[number];

export const FX: Record<Currency, number> = {
  USD: 1,
  EUR: 1.09,
  AED: 0.27,
  GBP: 1.27,
  JPY: 0.0068,
};

// Default marketplace fees
export const MARKETPLACE_FEE_BPS = 850; // 8.5%
export const PAYMENT_FEE_BPS = 290; // 2.9% (illustrative) + fixed handled by provider

export function convert(amount: number, from: Currency, to: Currency) {
  const usd = amount * (FX[from] || 1);
  return usd / (FX[to] || 1);
}

export function format(amount: number, currency: Currency) {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount);
  } catch {
    return amount.toFixed(0) + ' ' + currency;
  }
}

export function feesFor(amount: number) {
  const marketplace = Math.round(amount * MARKETPLACE_FEE_BPS / 10000);
  const payment = Math.round(amount * PAYMENT_FEE_BPS / 10000);
  return { marketplace, payment, total: marketplace + payment };
}
