
import { prisma } from '@/lib/db'
import { NextResponse } from 'next/server'
import { z } from 'zod'

const offerSchema = z.object({
  listingId: z.string().min(1),
  buyerId: z.string().min(1),
  amount: z.number().int().positive(), // minor units
  currency: z.string().min(3)
})

export async function POST(req: Request) {
  const body = await req.json()
  const parsed = offerSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  // Basic constraints
  const listing = await prisma.listing.findUnique({ where: { id: parsed.data.listingId } })
  if (!listing) return NextResponse.json({ error: 'Listing not found' }, { status: 404 })
  const offer = await prisma.offer.create({ data: parsed.data })
  return NextResponse.json(offer, { status: 201 })
}
