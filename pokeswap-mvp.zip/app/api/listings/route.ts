
import { prisma } from '@/lib/db'
import { NextResponse } from 'next/server'
import { z } from 'zod'

const listingSchema = z.object({
  title: z.string().min(2),
  set: z.string().min(1),
  number: z.string().min(1),
  rarity: z.string().min(1),
  condition: z.string().min(1),
  grading: z.string().min(1),
  grade: z.number().int().optional().nullable(),
  currency: z.string().min(3),
  price: z.number().int().positive(), // minor units
  imageUrl: z.string().url().optional().nullable(),
  sellerId: z.string().min(1),
  country: z.string().min(2)
})

export async function GET() {
  const listings = await prisma.listing.findMany({
    where: { status: 'active' },
    include: { seller: true },
    orderBy: { createdAt: 'desc' }
  })
  return NextResponse.json(listings)
}

export async function POST(req: Request) {
  const body = await req.json()
  const parsed = listingSchema.safeParse(body)
  if (!parsed.success) return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
  const listing = await prisma.listing.create({ data: parsed.data })
  return NextResponse.json(listing, { status: 201 })
}
