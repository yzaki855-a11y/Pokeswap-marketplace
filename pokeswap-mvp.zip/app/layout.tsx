
import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'PokéSwap – Global TCG Marketplace',
  description: 'Buy & sell Pokémon cards worldwide with escrow and shipping built-in.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
