
'use client'

import { useEffect, useMemo, useState } from 'react'
import { Currency, SUPPORTED_CURRENCIES, convert, format } from '@/lib/pricing'

type Listing = {
  id: string
  title: string
  set: string
  number: string
  rarity: string
  condition: string
  grading: string
  grade?: number | null
  currency: string
  price: number
  imageUrl?: string | null
  seller: { id: string, name: string | null, country: string | null }
  country: string
}

export default function Page() {
  const [listings, setListings] = useState<Listing[]>([])
  const [q, setQ] = useState('')
  const [currency, setCurrency] = useState<Currency>('USD')
  const [gradedOnly, setGradedOnly] = useState(false)
  const [rarity, setRarity] = useState('all')

  useEffect(() => {
    fetch('/api/listings').then(r => r.json()).then(setListings).catch(()=>{})
  }, [])

  const filtered = useMemo(() => {
    const query = q.toLowerCase()
    return listings.filter(l => {
      const matches = [l.title, l.set, l.number].some(x => x.toLowerCase().includes(query))
      const rarityOk = rarity === 'all' || l.rarity === rarity
      const gradedOk = !gradedOnly || (l.grading && l.grading !== 'Raw')
      return matches && rarityOk && gradedOk
    })
  }, [listings, q, rarity, gradedOnly])

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 bg-white/70 backdrop-blur border-b">
        <div className="container-xxl py-3 flex items-center gap-3">
          <div className="font-bold text-xl">PokéSwap</div>
          <span className="badge border-neutral-300">Global TCG Marketplace</span>
          <div className="ml-auto flex items-center gap-2">
            <select className="select" value={currency} onChange={e=>setCurrency(e.target.value as Currency)}>
              {SUPPORTED_CURRENCIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </header>

      <section className="container-xxl py-4">
        <div className="card p-4">
          <div className="grid gap-3 md:grid-cols-12 items-center">
            <div className="md:col-span-6">
              <input className="input" placeholder="Search by name, set, or number" value={q} onChange={e=>setQ(e.target.value)} />
            </div>
            <div className="md:col-span-3">
              <select className="select w-full" value={rarity} onChange={e=>setRarity(e.target.value)}>
                <option value="all">All rarities</option>
                <option>Common</option>
                <option>Uncommon</option>
                <option>Rare</option>
                <option>Ultra Rare</option>
                <option>Secret Rare</option>
              </select>
            </div>
            <div className="md:col-span-3 flex items-center gap-2">
              <input id="graded" type="checkbox" checked={gradedOnly} onChange={e=>setGradedOnly(e.target.checked)}/>
              <label htmlFor="graded" className="text-sm">Graded only</label>
              <button className="btn ml-auto">List a Card</button>
            </div>
          </div>
        </div>
      </section>

      <main className="container-xxl pb-20">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map(l => (
            <div className="card overflow-hidden" key={l.id}>
              <div className="p-3">
                <div className="flex items-center justify-between">
                  <div className="font-semibold">{l.title}</div>
                  <span className="badge border-yellow-300 bg-yellow-50">{l.rarity}</span>
                </div>
                <div className="text-xs text-neutral-500">{l.set} • #{l.number}</div>
              </div>
              <div className="aspect-[4/3] bg-neutral-100 flex items-center justify-center">
                {l.imageUrl ? (<img src={l.imageUrl} alt={l.title} className="object-contain w-full h-full" />) : (<div className="text-neutral-400">No image</div>)}
              </div>
              <div className="p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs text-neutral-500">Listed</div>
                  <div className="text-lg font-bold">
                    {format(Math.round(convert(l.price/100, l.currency as any, currency)), currency)}
                  </div>
                </div>
                <div className="text-xs text-neutral-500">Seller: {l.seller?.name || '—'} • {l.country}</div>
              </div>
              <div className="p-3 pt-0 flex gap-2">
                <button className="btn">Price</button>
                <button className="btn btn-primary">Offer</button>
              </div>
            </div>
          ))}
        </div>
        {filtered.length === 0 && (<div className="text-center text-neutral-500 py-16">No cards match your filters yet.</div>)}
      </main>

      <footer className="border-t bg-white/60 backdrop-blur">
        <div className="container-xxl py-6 grid gap-4 md:grid-cols-3 items-center">
          <div className="text-sm text-neutral-600">© {new Date().getFullYear()} PokéSwap — Buy & Sell Pokémon cards worldwide.</div>
          <div className="text-sm text-neutral-500">Fees: 8.5% marketplace + payment processing.</div>
          <div className="md:text-right text-sm">USA • EU/EEA • UK • UAE • Japan at launch</div>
        </div>
      </footer>
    </div>
  )
}
